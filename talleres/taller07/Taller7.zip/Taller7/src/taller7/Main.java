
package taller7;

/**
 * Taller 7. Clase donde se realizan las pruebas
 *
 * @author Alejandro Cano Munera
 * @author Jorge Luis Herrera Chamat
 * @version Agosto de 2017
 */
public class Main extends Lista {
    public static void main(String[] args) {  
        //Creando lista 1
        Lista lista = new Lista();
        lista.agregar_al_Final(1);
        lista.agregar_al_Final(2);
        lista.agregar_al_Final(3);
        lista.agregar_al_Final(4);
        
        //Creando lista 2
        Lista lista2 = new Lista();
        lista2.agregar_al_Final(1);
        lista2.agregar_al_Final(2);
        lista2.agregar_al_Final(3);
        lista2.agregar_al_Final(4);
        
        //Creando lista 3
        Lista lista3 = new Lista();
        lista3.agregar_al_Final(1);
        lista3.agregar_al_Final(2);
        
        //Creando lista 4
        Lista lista4 = new Lista();
        lista4.agregar_al_Final(3);
        lista4.agregar_al_Final(4);
        
        System.out.println("Pruebas: ");
        System.out.println("imprimir lista 1: ");
        lista.imprimir();
        System.out.println("imprimir lista 1 invertida: ");
        lista.imprimir_inverso();
        System.out.println("Agregar al inicio lista 1: ");
        lista.agregar_al_Inicio(0);
        lista.imprimir();
        System.out.println("Agregar al final lista 1: ");
        lista.agregar_al_Final(5);
        lista.imprimir();
        System.out.println("Borrar al inicio: ");
        lista.borrarInicio();
        lista.imprimir();
        System.out.println("Borrar al final: ");
        lista.borrarFinal();
        lista.imprimir();
        System.out.println("Maximo lista 1: "+maximo(lista));
        System.out.println("Maximo lista 3: "+maximo(lista3));
        System.out.println("Comparando lista 1 y lista 2: "+lista.comparar(lista2));
        System.out.println("Comparando lista 3 y lista 4: "+lista3.comparar(lista4));
    }
}
