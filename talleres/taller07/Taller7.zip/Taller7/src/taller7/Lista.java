package taller7;

/**
 * Taller 7.
 *
 * @author Alejandro Cano Munera
 * @author Jorge Luis Herrera Chamat
 * @version Agosto de 2017
 */
public class Lista {

    //Atributo de lista
    Nodo inicio;

    //Inicio Clase Nodo
    public class Nodo {

        //Atributos de Nodo
        int data;         //Contiene el numero entero del nodo
        Nodo siguiente;   //Puntero al siguiente nodo

        /**
         * Constructor de la clase Nodo
         *
         * @param data es el entero que contiene el nodo
         */
        public Nodo(int data) {
            this.data = data;
        }
    }
    //Fin clase Nodo

    /**
     * Constructor de la clase Lista. Se inicializa el inicio de la lista como
     * null
     */
    public Lista() {
        inicio = null;
    }

    /**
     * Punto 1. Metodo agregar_al_Inicio(int n). Este metodo recive un entero n
     * y lo agrega al inicio de la Lista
     *
     * @param n es el numero que se va a agregar al inicio de la lista
     */
    public void agregar_al_Inicio(int n) {
        Nodo nuevo = new Nodo(n);
        if (inicio != null) {
            nuevo.siguiente = inicio;
            inicio = nuevo;
        } else {
            inicio = nuevo;
        }
    }

    /**
     * Punto 1. metodo imprimir(). Este metodo imprime la lista.
     */
    public void imprimir() {
        Nodo nodo = inicio;
        while (nodo != null) {
            System.out.print(nodo.data);
            if (nodo.siguiente != null) {
                System.out.print(", ");
            }
            nodo = nodo.siguiente;
        }
        System.out.println();
    }

    /**
     * metodo agregar_al_Final(int n). Este metodo recive un entero n y lo
     * agrega al final de la Lista
     *
     * @param n es el numero que se va a agregar al final de la lista
     */
    public void agregar_al_Final(int n) {
        Nodo nuevo = new Nodo(n);
        if (inicio != null) {
            Nodo index = inicio;
            while (index.siguiente != null) {
                index = index.siguiente;
            }
            index.siguiente = nuevo;
        } else {
            inicio = nuevo;
        }
    }

    /**
     * Punto 2a. metodo imprimir_inverso(). este metodo imprime los elementos de
     * la lista en orden inverso (es decir, del ultimo al primero).
     */
    public void imprimir_inverso() {
        Nodo nodo = inicio;
        int cont = 0;
        while (nodo.siguiente != null) {
            cont++;
            nodo = nodo.siguiente;
        }
        for (int i = cont; i >= 0; i--) {
            imprimir(i);
            if (i != 0) {
                System.out.print(", ");
            }
        }
        System.out.println();
    }

    /**
     * Punto 2b. Metodo imprimir(int n). Este metodo imprime el elemento que se
     * encuentra en la posición n de la lista.
     *
     * @param n es la posicion del elemento que se va a imprimir.
     */
    public void imprimir(int n) {
        Nodo nodo = inicio;
        int posicion = 0;
        while (posicion < n) {
            if (nodo == null) {
                System.out.println("Posicion inexistente");
                System.out.println();
                break;
            } else {
                nodo = nodo.siguiente;
            }
            posicion++;
        }
        if (nodo != null) {
            System.out.print(nodo.data);
        }
    }

    /**
     * Punto 2c. metodo borrarFinal(). Este metodo borra el elemento del final
     * de la lista.
     */
    public void borrarFinal() {
        Nodo auxiliar = inicio;
        while (auxiliar.siguiente.siguiente != null) {
            auxiliar = auxiliar.siguiente;
        }
        auxiliar.siguiente = null;
    }

    /**
     * Punto 2d. metodo borrarInicio(). Este metodo borra el elemento del inicio
     * de la lista.
     */
    public void borrarInicio() {
        Nodo aux = inicio;
        inicio = aux.siguiente;
    }

    /**
     * Punto 3. Metodo maximoAux(Nodo nodo). Que se utiliza para buscar el
     * maximo recursivamente.
     *
     * @param nodo
     * @return
     */
    private static int maximoAux(Nodo nodo) {
        int max, temp = 0;
        max = nodo.data;
        if (nodo.siguiente != null) {
            temp = maximoAux(nodo.siguiente);
        }
        if (temp > max) {
            max = temp;
        }
        return max;
    }

    /**
     * Punto 3. metodo maximo(Lista lista). este metodo recibe una lista y llama
     * a el metodo maximoAux(lista.inicio) quien claculara el maximo
     * recursivamente.
     *
     * @param lista Es la lista de elementos a la cual se le calculara el maximo.
     * @return el valor de retorno es el maximo.
     */
    public static int maximo(Lista lista) {
        return maximoAux(lista.inicio);
    }
    
    /**
     * Punto4. metodo comparar(Lista lista). Este metodo recibe una lista y la
     * compara, si son iguales retorna true y si son diferentes retorna false.
     *
     * @param lista Es la lista con la que vamos a comparar
     * @return true si las listas son iguales, y false si son diferentes.
     */
    public boolean comparar(Lista lista) {
        Nodo nodo1 = inicio;
        Nodo nodo2 = lista.inicio;
        while (nodo1 != null || nodo2 != null) {
            if (nodo1 == null && nodo2 != null || nodo2 == null && nodo1 != null || nodo1.data != nodo2.data) {
                return false;
            }
            nodo1 = nodo1.siguiente;
            nodo2 = nodo2.siguiente;
        }
        return true;
    }

}
